/*************************************************************
Class:     CSCI 470-1
Program:   Assignment 2
Author:    Shreyas Javvadhi
Z-number:  z1809837
Date Due:  03/07/17

Purpose:   To implement the Dte class. 

Execution: java Hw2 file path/filename.

**************************************************************/

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Stream;
import java.util.Scanner;
import java.io.File;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/****************************************************************
Class:     Hw2
Author:    Shreyas Javvadhi
Z-number:  z1809837
Description: Handles all exceptions and the non-member fuctions
	      of the Dte class.
****************************************************************/

public class Hw2{

public static void main(String args[])
{
	String fileName = args[0];
	String calDates = "";
	int pIncrement = 0;
	String c;
	try (Scanner scanner = new Scanner(new File(fileName)))
	{
		while(scanner.hasNextLine())
		{
			calDates = scanner.nextLine();
			calDates = calDates.replaceAll(" ","");
		  if(calDates.contains("/"))
		  {
			String[] calDates1 = calDates.split("/");
			int month = Integer.parseInt(calDates1[0]);
			int day = Integer.parseInt(calDates1[1]);
			String calDates2 = calDates1[2];
			int year = Integer.parseInt(calDates2.substring(0, 4));
			if(validation(day))
			{
				if(calDates2.length()>4)
				{
					Dte a = new Dte(month,day,year);
                        		Dte b = new Dte(a);
					c = calDates2.substring(4);
					boolean isDigit = c.matches("\\d{3}");
					boolean isDigit1 = c.matches("\\d{2}");
					boolean isDigit2 = c.matches("\\d{1}");
					if(isDigit || isDigit1 || isDigit2)
					{
					pIncrement = Integer.parseInt(calDates2.substring(4));
					a.addDays(pIncrement);
					System.out.printf("After adding the date is: %s%n",a); 
					b.subDays(pIncrement);
					System.out.printf("After subtracting the date is: %s%n",b);
					}
					else
						System.out.println("Increment is not numeric");
				}
				else
				System.out.println("No increment");
		        }
			else
			System.out.println("Day is out of range");
		   }
		   else
		   {
		  	if(calDates.isEmpty())
		  	System.out.println("Line is Empty");
			else
			System.out.println("Date does not contain slashes");
		   }
}


}
	catch (IOException e)
	{
		System.out.println("Wrong filename");
	}
}

public static Dte addDays(Dte d, int inc)
	{
		Dte st = new Dte(d) ;
		st.addDays(inc);
		return st;
	}
public static Dte subDays(Dte d, int ninc)
	{
		Dte st = new Dte(d) ;
		st.subDays(ninc);
		return st;
	}


public static boolean validation(int d)
{
if(d > 0 && d <= 31)
return true;
else
return false;
}

}
