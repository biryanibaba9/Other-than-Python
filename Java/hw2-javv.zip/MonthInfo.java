/*************************************************************
Class:     CSCI 470-1
Program:   Assignment 2
Author:    Shreyas Javvadhi
Z-number:  z1809837
Date Due:  03/07/17

Purpose:   To create an array for the date calculations.
**************************************************************/

public class MonthInfo
{
int number_of_days;
String month;
	public MonthInfo (String month, int number_of_days)
	{
		this.number_of_days = number_of_days;
		this.month = month;
	}
}
