/*************************************************************
Class:     CSCI 470-1
Program:   Assignment 2
Author:    Shreyas Javvadhi
Z-number:  z1809837
Date Due:  03/07/17

Purpose:   To perform calculations on date.
**************************************************************/


public class Dte{

private int day;		//Declaration of private variables.
private int month;
private int year;

static MonthInfo[] mData = {new MonthInfo("Jan",31), new MonthInfo("Feb",28), new MonthInfo("Mar",31), new MonthInfo("Apr",30), new MonthInfo("May",31), new MonthInfo("Jun",30), new MonthInfo("Jul",31), new MonthInfo("Aug",31), new MonthInfo("Sep",30), new MonthInfo("Oct",31), new MonthInfo("Nov",30), new MonthInfo("Dec",31)};

public void addDays (int daysToAdd)			// Function to add 'n' days to a date.
{
	day = day + daysToAdd;
		while (day > maxDays())
		{
			if(isLeapYear(year,month))
			{
			day = day-1;
			}
			day = day - maxDays();
			month++;
			if (month > 12)
			{
			year++;
			month = 1;
			}
		}
}

public int maxDays()			// Function to return the maximum days in a particular month.
{
	int md = mData[month-1].number_of_days;
	return md;
}

public Dte(int month,int day,int year)
{
this.month = month;
this.day = day;
this.year = year;
}

public void subDays (int nIncrement)		//Function to subtract 'n' days from a date.
{
	int tDays = nIncrement*(-1);
        int mIndex;
        while(tDays < 0)
        {
	    if(day == 1)
            		{
               			mIndex = month-1;
               			if(mIndex >= 0)
               			{
                   			if(mIndex == 0)
                   			{
                       			month = 12 ;
                       			year--;
                       		        }
                   		else
                   		month--;
                                }
                		if(isLeapYear(year,month))
				{
					day = day + 1;
				}
			day = mData[month-1].number_of_days ;
                	tDays++ ;
              		}
              		else
              		{
                 		day--;
                 		tDays++;
              		}
         }
}

public boolean isLeapYear (int year, int month)			//Function to check leap year condition.
{
if( month == 2 && ( year % 400 == 0 || ( year % 4 == 0 && year % 100 != 0)))
	return true;
else
	return false;
}

public Dte()
{
this.day = 0;
this.month = 0;
this.year = 0;
}

public Dte (Dte a)
{
day = a.day;
month = a.month;
year = a.year;
}

/*********************************************************************

Getters for Dte class

***********************************************************************/

public int getDay()
{
return this.day;
}

public int getMonth()
{
return this.month;
}

public int getYear()
{
return this.year;
}

/************************************************************************

Setters for Dte class

**************************************************************************/

public void setDay (int day)
{
this.day = day;
}

public void setMonth (int month)
{
this.month = month;
}

public void setYear (int year)
{
this.year = year;
}

/*toString Function*/
@Override
public String toString()
{
return month + "/" + day + "/" + year;
}
}
