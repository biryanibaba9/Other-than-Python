/*************************************************************
Class:     CSCI 470-1
Program:   Assignment 4
Author:    Shreyas Javvadhi
Z-number:  z1809837
Date Due:  07/05/17

Purpose:   To remove non Ascii charcters from a movie file. 

Execution: java Hw4

**************************************************************/

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

/****************************************************************
Class:     Hw4
Author:    Shreyas Javvadhi
Z-number:  z1809837
Description: Contains the main function and the function calls 
		to all the related methods.
****************************************************************/

public class Hw4
{
	public static void main(String[] args)
        {
		List<String> lines = new ArrayList<String>();
		List<String> lv = new ArrayList<String>();
	   	MovieFileOperations mv = new MovieFileOperations();
	   	lines = mv.readFile("/home/turing/t90rkf1/d470/dhw/hw4-movies/movie-names.txt");
	   	lv = mv.readFile("/home/turing/t90rkf1/d470/dhw/hw4-movies/movie-names.txt");
	   	mv.printNonAsciiLines(lines);
	   	lines = mv.removeNonAsciiChars(lines);
	   	System.out.println("Total number of Non-ASCII characters = "+mv.countNonAsciiChars(lv));
	   	System.out.println("Number of lines containing Non-ASCII characters = "+mv.countNonAsciiLines(lv));
	   	System.out.println("Total record count = "+lines.size());
	   	mv.createNewMovieNamesFile(lines);
           	lines = mv.readFile("/home/turing/t90rkf1/d470/dhw/hw4-movies/movie-matrix.txt");
	   	MovieMatrix mm = mv.createMovieMatrix(lines);	  
           		try
           		{
	    			FileOutputStream fileOut = new FileOutputStream("movie-matrix2.ser");
	    			ObjectOutputStream out = new ObjectOutputStream(fileOut);
				out.writeObject(mm);
            			out.close();
	    			fileOut.close();
	   		}
           			catch(IOException i) 
           			{
	    			i.printStackTrace();
	   			}
	  }
}
