/*************************************************************
Class:     CSCI 470-1
Program:   Assignment 4
Author:    Shreyas Javvadhi
Z-number:  z1809837
Date Due:  07/05/17

Purpose:   To create a serialized movie matrix. 

**************************************************************/

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/****************************************************************
Class:     MovieMatrix
Author:    Shreyas Javvadhi
Z-number:  z1809837
Description: Contains fucntions to create a serialized file and 
		compare the mean and averages.
****************************************************************/


public class MovieMatrix implements Serializable
{
 private static final long serialVersionUID = 1L;
 public List<List<String>> movieMatrix = new ArrayList<List<String>>();
 public List<String> movieNames = new ArrayList<>();

 public MovieMatrix(List<List<String>> movieMatrix,List<String> movieNames)
 {
  this.movieMatrix = movieMatrix;
  this.movieNames=movieNames;
  for(int i=0;i<this.movieMatrix.size();i++)
  {
   for(int j=0;j<this.movieMatrix.get(i).size();j++)
   {
    this.movieMatrix.get(i).get(j).trim();
   }
  }
 }

	
public int numberOfPeopleWhoRatedBothMovies(int movieNumber, int comparingMovie){
 List<String> m1 = movieMatrix.get(movieNumber);
 List<String> m2 = movieMatrix.get(comparingMovie);
 int maxSize = m1.size()<m2.size()?m1.size():m2.size();
 int peopleRatedBothMovies = 0;
 for(int i=0;i<maxSize;i++)
 {
  if(m1.get(i).length()>0&&m2.get(i).length()>0)
  {
   peopleRatedBothMovies++;
  }
 }
 return peopleRatedBothMovies;
}

//this function is used for returng the pearson coefficient	
public float getPearson(List<String> a,List<String> b)
{
 List<Integer> A = new ArrayList<>();
 for(int i=0;i<a.size();i++)
 {
  String s = a.get(i).trim();
  if(s.length()>0)
  {
   A.add(Integer.parseInt(s));
  }
  else
  {
   A.add(0);
  }
 }
 List<Integer> B = new ArrayList<>();
 for(int i=0;i<b.size();i++)
 {
  String s = b.get(i).trim();
  if(s.length()>0)
  {
   B.add(Integer.parseInt(s));
  }
  else
  {
   B.add(0);
  }
 }
 if(a.size()>b.size())
 {
  int sizeDiff = a.size()-b.size();
  for(int i=0;i<sizeDiff;i++)
  {
   B.add(0);
  }
 }
 else
 {
  int sizeDiff = b.size()-a.size();
  for(int i=0;i<sizeDiff;i++)
  {
   A.add(0);
  }
 }
 float mean1=getMean(A);       //calling mean function
 float mean2=getMean(B);
 float deviation1=getDeviation(A,mean1);   //calling deviation function
 float deviation2=getDeviation(B,mean2);
 float score=0;
 for(int i=0;i<a.size();i++)
 {
  float diff1=((float)A.get(i))-mean1;
  float diff2=(float)B.get(i)-mean2;
  score+=((diff1/deviation1)*(diff2/deviation2))/(a.size()-1);
 }
 return score;
}
 

//this function is used for calculating the mean and returning it   
public float getMean(List<Integer> a)
{
 float sum=0;
 int length=a.size();
 for(int t1=0;t1<length;t1++)
 {
  sum=sum+a.get(t1);
 }
 float mean=sum/(float)length;
 return mean;
}
 
//this function is used for calculting and returning the standard deviation   
public float getDeviation(List<Integer> a,float mean)
{
 double temp=0;
 for(int i=0;i<a.size();i++)
 {
  temp+=Math.pow(a.get(i)-mean,2);//squaring the difference xi and mean 
 }
 return (float)Math.sqrt(temp/((double)a.size()-1)); 
}
 
//this funtion is used for printing the comparison between both the movies using the pearson coefficient.
public void printComparisons(float[] comparisons,int[] movieNumbers,int selectedMovieNumber)
{
 for(int i=0;i<20;i++)
 {
  System.out.printf("%4d",i+1);
  System.out.printf( "%10.6f",comparisons[i]);
  System.out.printf(" %4d ",(movieNumbers[i]+1));	
  String movieName = movieNames.get(movieNumbers[i]);
  int index=movieName.indexOf("|");
  movieName=movieName.substring(index+1);
  System.out.printf(" %-30s", movieName); 
  System.out.printf("\n");
  }
 }
}


