/*************************************************************
Class:     CSCI 470-1
Program:   Assignment 1
Author:    Shreyas Javvadhi
Z-number:  z1809837
Date Due:  02/05/17

Purpose:   All the method definitions to remove the non Ascii
		characters and create a serialized file.

Execution: javac MovieFileOperations.java

**************************************************************/

import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.Map;
import java.util.HashMap;

/****************************************************************
Class:     MovieFileOperations
Author:    Shreyas Javvadhi
Z-number:  z1809837
Description: Contains all the functions definitions to remove the 
		non Ascii characters.
****************************************************************/

public class MovieFileOperations 
{
	 static String FILENAME ="movie-names.txt";
	 private int numberOfNonAsciiChars =0;
	 private int numberofNonAsciiLines =0;
	 public List<String> movieNames = new ArrayList<>();
	 public List<String> movieNamesBeforeEditing = new ArrayList<>();

/*****************************************************************
Function: readFile(String FileName)

Purpose: This function is used for reading the file.
*****************************************************************/
public List<String> readFile(String FileName)
{
  List<String> movieNames = new ArrayList<>();
  try(BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(FileName),"ISO-8859-1")))
  {
    String line;
    while ((line = br.readLine()) != null) 
    {
     movieNames.add(line);
    }
  }
  catch (FileNotFoundException e) 
  {
   e.printStackTrace();
  }
  catch (IOException e) 
  {
   e.printStackTrace();
  } 
 return movieNames;
}
/*****************************************************************
Function:printNonAsciiLines

Purpose: This function is used for printing all the lines with
         non-ASCII characters.
*****************************************************************/
public void printNonAsciiLines(List<String> lines)
{
for(int i=0;i<lines.size();i++)
 {
  String line = lines.get(i);
	for(char c:line.toCharArray())
	{
	if((!lines.get(i).matches("\\A\\p{ASCII}*\\z")) &&(!String.valueOf(c).matches("\\A\\p{ASCII}*\\z")))
		{
          	/*System.out.println("non-Ascii char: "+String.valueOf(c)+" in line "+(i+1)+" char at ");
		System.out.println(line);
		//System.out.println("");*/
		}
	}
 }
}
/*****************************************************************
Function: countNonAsciiLines

Purpose: This function is used for counting the lines with 
         non-ASCII characters..
*****************************************************************/
public int countNonAsciiLines(List<String> lines)
{
 for(int i=0;i<lines.size();i++)
 {
  if(!lines.get(i).matches("\\A\\p{ASCII}*\\z"))
   numberofNonAsciiLines++;
 }
 return numberofNonAsciiLines;
}
/*****************************************************************
Function: countNonAsciiChars

Purpose: This function is used for counting the number of 
         non-ASCII characters in the file.
*****************************************************************/
public int countNonAsciiChars(List<String> lines)
{
 for(int i=0;i<lines.size();i++)
 {
  String line = lines.get(i);
  for(char c:line.toCharArray())
  {
   if(!String.valueOf(c).matches("\\A\\p{ASCII}*\\z"))
   numberOfNonAsciiChars++;
  }
 }
 return numberOfNonAsciiChars;
}

/*****************************************************************
Function: removeNonAsciiChars

Purpose: This function is used for replacing the non-ASCII 
         characters with the ASCII characters.
*****************************************************************/
public List<String> removeNonAsciiChars(List<String> lines)
{
 for(int i=0;i<lines.size();i++)
 {
  String line = lines.get(i);
 	 for(int j=0;j<line.length();j++)
	{
		if(line.charAt(j) > 127)
			{
				StringBuilder s = new StringBuilder(line);
				HashMap<Character,Character> charMap = new HashMap<Character, Character>();
				charMap.put('\u00E8','e');
				charMap.put('\u00E9','e');
				charMap.put('\u00F6','o');
				charMap.put('\u00C1','A');
				for(;j<s.length();j++)
				{
					if(s.charAt(j) > 127)
					{
						System.out.println("non-Ascii char: "+s.charAt(j)+" in line "+(i+1)+" char at "+(j+1));
						char ch = charMap.get(s.charAt(j));
						s.setCharAt(j, ch);
						//System.out.println("non-Ascii char: "+s.charAt(j)+" in line "+(i+1)+" char at "+j+1);
						System.out.println(line);
						System.out.println(" ");
					}
						//System.out.println(line);
				}
					line = s.toString();
			}
	}
/*if(!line.matches("\\A\\p{ASCII}*\\z"))
  {
   line = Normalizer.normalize(line, Normalizer.Form.NFD);
   line=line.replaceAll("[^\\x00-\\x7F]", "");
  }*/
  movieNamesBeforeEditing.add(line);
 // movieNames.add(line.replace('|',' '));
  String str =line.substring(0,line.indexOf("|"));
  if(str.length() == 1)
	str ="000";
  else if(str.length() == 2)
	str = "00";
  else if(str.length() == 3)
	str = "0";
  else
	{
	str = "";
	}
 line = str+line;
 movieNames.add(line.replace('|',' '));
}
 return movieNames;
}
/*****************************************************************
Function: createMovieMatrix

Purpose: This function is used for making the serialized matrix.
*****************************************************************/
public MovieMatrix createMovieMatrix(List<String> lines)
{
 List<List<String>> movieMatrix = new ArrayList<List<String>>();
 for(int i=0000;i<lines.size();i++)
 {
  String line =lines.get(i);
  movieMatrix.add(Arrays.asList(line.split(";")));
 }
 return new MovieMatrix(movieMatrix,movieNamesBeforeEditing);
}
/*****************************************************************
Function: createNewMovieNamesFile

Purpose: This function is used for creating a new text file for
         saving the list of movies after removing the delimiter
         and the non-ASCII characters.
*****************************************************************/	
public void createNewMovieNamesFile(List<String> movieNames)
{
 try
 {
  PrintWriter writer = new PrintWriter("movie-names2.txt", "UTF-8");
  Iterator<String> i = movieNames.iterator();
  while(i.hasNext())
  {
   writer.println(i.next());
  }
  writer.close();
 } 
 catch (IOException e) 
 {
  e.printStackTrace();
 }
}

/*****************************************************************
Function: createSerializationMovieMatrix
*****************************************************************/	
public void createSerializedMovieMatrix(String fileName, MovieMatrix mm)
{
 try 
 {
  FileOutputStream fileOut = new FileOutputStream(fileName);
  ObjectOutputStream out = new ObjectOutputStream(fileOut);
  out.writeObject(mm);
  out.close();
  fileOut.close();
  System.out.printf("Serialized data is saved in movie-matrix2.ser");
 }
 catch(IOException i) 
 {
  i.printStackTrace();
 }
}
/*****************************************************************
Function: deserializationMovieMatrix

Purpose: This function is used for deserializing the matrix.
*****************************************************************/	
public MovieMatrix deserializeMovieMatrix(String fileName)
{
 MovieMatrix mm =null;
 try (ObjectInputStream ois= new ObjectInputStream(new FileInputStream(fileName))) 
 {
  mm = (MovieMatrix) ois.readObject();
 }
 catch (Exception ex) 
 {
  ex.printStackTrace();
 }
 return mm;
 }
}


