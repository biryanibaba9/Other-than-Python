/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/***********************************************
 Name : Gayatri Thota
 CSCI 680 Spring 2017
 Assignment 3
 Due: 5\26\2017
 Topic covered: Net beans , Swing GUI
 Description: To create a simple calculator with 4 operations and handling 
 the exceptions.
  
 *******************************************************/
//
    
    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package sample;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
/**
 *Hw3 class implements the following listeners. The class contains the 
 *respective Jframes, Jpanel, textfields to take input, buttons,menuItems,
 * radiobutton,checkox and Jpanel.
 * 
 */
public class Hw3 implements ActionListener, ItemListener{
    
    /* Starter GUI program */
    private JFrame frame,frame1;
    private JTextField xfield;
    private JTextField yfield;
    private JLabel result,xlabel,ylabel;
    private final JButton addButton;
    private final JButton subButton,mulButton,divButton,clearButton, cal2;
    private JPanel xpanel;
    private JPanel panel1;
    private final JMenuItem aboutItem;
    private final JMenuItem proItem;
    private JRadioButton addButton1;
    private JRadioButton subButton1;
    private JRadioButton mulButton1;
    private JRadioButton divButton1;
    private JRadioButton clearButton1;
    private JCheckBox box; 
    
    public Hw3()                                                                                                                            
      {
        frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        frame.setBackground(Color.GREEN);
        
       JMenu fileMenu = new JMenu("About..");
       aboutItem = new JMenuItem("People");
       proItem = new JMenuItem("Project");
       JMenuBar bar = new JMenuBar(); 
       bar.add(fileMenu);
       fileMenu.add(aboutItem);
       fileMenu.add(proItem);
       frame.setJMenuBar(bar);
       aboutItem.addActionListener(new java.awt.event.ActionListener(){
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt){
                jActionPerformed(evt);
            }
        });
       proItem.addActionListener(new java.awt.event.ActionListener(){
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt){
                jActionPerformed(evt);
            }
        });
                
        addButton=new JButton("+");
        subButton=new JButton("-");
        mulButton =new JButton("*");
        divButton=new JButton("/");
        clearButton=new JButton("Clear");
        cal2=new JButton("Calculator 2");
    
        
        xpanel = new JPanel();
        xpanel.setLayout(new GridLayout(3,2));
        xpanel.setBorder(BorderFactory.createEtchedBorder());
            xlabel = new JLabel("x:");
            xlabel.setHorizontalAlignment(SwingConstants.RIGHT);
        xpanel.add(xlabel);
        xfield = new JTextField("0", 5);
        xpanel.add(xfield);

        ylabel = new JLabel("y:");
        ylabel.setHorizontalAlignment(SwingConstants.RIGHT);
        xpanel.add(ylabel);
        yfield = new JTextField("0", 5);
        xpanel.add(yfield);
        JLabel e = new JLabel("result");
        
        e.setForeground(Color.red);
             
        xpanel.add(e);
        result = new JLabel("0");
        result.setBackground(Color.yellow);
        result.setOpaque(true);
      
        xpanel.add(result);
        
        xpanel.setLayout(new FlowLayout());
        panel1 = new JPanel();
        panel1.setBorder(BorderFactory.createEtchedBorder());
        panel1.setBackground(Color.GREEN);
        xpanel.setBackground(Color.GREEN);
        panel1.add(addButton);
        panel1.add(subButton);
        panel1.add(mulButton);
        panel1.add(divButton);
        panel1.add(clearButton);
        panel1.add(cal2);
    
        addButton.addActionListener(this);
        subButton.addActionListener(this);
        mulButton.addActionListener(this);
        divButton.addActionListener(this);
        clearButton.addActionListener(this);
        cal2.addActionListener(this);

        frame.add(xpanel,BorderLayout.NORTH);
        frame.add(panel1,BorderLayout.SOUTH);

        frame.pack();
        frame.setVisible(true);
  }
/*
    this function is used to display menu items
    */
    public void jActionPerformed(ActionEvent event) {
         //To change body of generated methods, choose Tools | Templates.
         
         if(event.getSource()== aboutItem)
         {
             JOptionPane.showMessageDialog(aboutItem,
                  "Name: Gayatri Thota",
                  "People", JOptionPane.PLAIN_MESSAGE);
         }
         if(event.getSource()== proItem)
         {
             JOptionPane.showMessageDialog(proItem,
                  "This project helps us understand how Netbeans works in depth. We also create two different calculators.",
                  "Project", JOptionPane.PLAIN_MESSAGE);
         

    }
    }
     /*
    This is for JButtons
    */ 
    
    @Override
    public void actionPerformed(ActionEvent event) {
         //To change body of generated methods, choose Tools | Templates.
         int x = 0;
        int y = 0;

        String xText = xfield.getText();
        String yText = yfield.getText();

        try//exceptions are handled
          {
            x = Integer.parseInt(xText);
            System.out.println(x);
          }
        catch (NumberFormatException e2)
          {
           result.setText("error");
          }

        try
          {
            y = Integer.parseInt(yText);
          }
        catch (NumberFormatException e1)
          {
            result.setText("error");
          }

        if(event.getSource()== addButton)
        {
          String w=Integer.toString(x+y);
          result.setText(w);  
        }
        if(event.getSource()==subButton)
        {
          String w=Integer.toString(x-y);
          result.setText(w);
        }
        if(event.getSource()== mulButton)
        {
           String w=Integer.toString(x*y);
          result.setText(w); 
        }
        if(event.getSource()== divButton)
        {
          String w=Integer.toString(x/y);
          if(y==0)
          result.setText("Divide by zero");
          else
          result.setText(w);  
        }
        if(event.getSource()== clearButton)
        {
            
          result.setText("0");
          xfield.setText("0");
          yfield.setText("0");
          
        }
        if(event.getSource()== cal2)//this creates a new frame calculator 2
        {
        frame1 = new JFrame();
        frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame1.setLayout(new BorderLayout());
       
        addButton1 =new JRadioButton("+");
        subButton1=new JRadioButton("-");
        mulButton1 =new JRadioButton("*");
        divButton1=new JRadioButton("/");
        clearButton1=new JRadioButton("Exit");
        panel1 = new JPanel();
        panel1.add(addButton1);
        panel1.add(subButton1);
        panel1.add(mulButton1);
        panel1.add(divButton1);
        panel1.add(clearButton1);
        //this group is for radio buttons
        ButtonGroup group = new ButtonGroup();
        group.add(addButton1);
        group.add(subButton1);
        group.add(mulButton1);
        group.add(divButton1);
        group.add(clearButton1);
        
        box = new JCheckBox("result in float");
        frame.add(box);
   
        panel1.setLayout(new FlowLayout());

        xpanel = new JPanel();
        xpanel.setLayout(new GridLayout(1,1));
        xpanel.setBorder(BorderFactory.createEtchedBorder());
        xlabel = new JLabel("x:");
        xlabel.setHorizontalAlignment(SwingConstants.RIGHT);
        xpanel.add(xlabel);
        xfield = new JTextField("0", 5);
        xpanel.add(xfield);


        ylabel = new JLabel("y:");
        ylabel.setHorizontalAlignment(SwingConstants.RIGHT);
        xpanel.add(ylabel);
        yfield = new JTextField("0", 5);
        xpanel.add(yfield);
        JLabel e = new JLabel("result");
        
          
      xpanel.add(e);
      result = new JLabel("0");
      
      //result.setForeground(Color.red);
      result.setBackground(Color.yellow);
      result.setOpaque(true);
      
      xpanel.add(result);
      panel1.add(box);
      xpanel.setLayout(new FlowLayout());
        
      panel1.setBorder(BorderFactory.createEtchedBorder());
      panel1.setBackground(Color.MAGENTA);
      xpanel.setBackground(Color.MAGENTA);
    
      addButton1.addItemListener (this);
      subButton1.addItemListener(this);
      mulButton1.addItemListener(this);
      divButton1.addItemListener(this);
      clearButton1.addItemListener(this);
      
      box.addItemListener(this);

        frame1.add(xpanel,BorderLayout.NORTH);
        frame1.add(panel1,BorderLayout.SOUTH);

        frame1.pack();
        frame1.setVisible(true);
  }

    
    
        }
    /*
    this function is for radio action buttons
    */
    @Override
     public void itemStateChanged(ItemEvent e){
         //To change body of generated methods, choose Tools | Templates.
         int x = 0;
        int y = 0;

        String xText = xfield.getText();
        String yText = yfield.getText();

        try//exception if the input is a char
          {
            x = Integer.parseInt(xText);
          }
        catch (NumberFormatException e2)
          {
           result.setText("error");
          }

        try//exception if the input is wrong
          {
            y = Integer.parseInt(yText);
          }
        catch (NumberFormatException e1)
          {
            result.setText("error");
          }
       
        if(addButton1.isSelected())
        {
          String w=Integer.toString(x+y);
          result.setText(w);  
        }
       
        if(subButton1.isSelected())
        {
          String w=Integer.toString(x-y);
          result.setText(w);
        }
       
        if(mulButton1.isSelected())
        {
           String w=Integer.toString(x*y);
          result.setText(w); 
        }
       
        if(divButton1.isSelected())
        {
          String w=Integer.toString(x/y);
          if(y==0)
          result.setText("Divide by zero");
          else if(box.isSelected())
          {
              double m;
              m = Double.parseDouble(xText);
              double n;
              n = Double.parseDouble(yText);
              double o = m/n;
              result.setText(Double.toString(o));
          }
          else
          result.setText(w);  
        }
       
        if(clearButton1.isSelected())
        {
            
        frame1.dispose();
          
        }
        int val1 =0;
        
        if(box.isSelected() == true)
        {
            String w = result.getText();
            double val = Double.parseDouble(w);
            result.setText(Double.toString(val));
        }
        else
            result.setText(Integer.toString(val1));
        
      }
      }

