/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package democalculator;

import java.awt.*;
import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JOptionPane;


/**
 *
 * @author shreyas
 */
public class Calculator extends javax.swing.JFrame
  {
    private final JFrame frame;
    private final JTextField xfield;
    private final JTextField yfield;
    private final JLabel result;
    private final JLabel xlabel;
    private final JLabel ylabel;
    private final JPanel xpanel;
    private final JPanel ypanel;
    private final JButton plus;
    private final JButton minus;
    private final JButton multiply;
    private final JButton divide;
    private final JButton clear;
    private final JMenuBar menubar;
    private final JMenu menu;
    private final JMenuItem jitem;
    private final JMenuItem jitem2;
    private final JMenuItem jitem3;
    private final JMenuItem jitem4;
    
    
    public Calculator()
      {
        frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        
        
        menubar = new JMenuBar();
       
        frame.setJMenuBar(menubar);
        
        menu = new JMenu("About");
        menubar.add(menu);
        jitem = new JMenuItem("People");
        menu.add(jitem);
        jitem.addActionListener(new java.awt.event.ActionListener(){
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt){
                jitemActionPerformed(evt);
            }
        });
        
        
        jitem2 = new JMenuItem("Project");
        menu.add(jitem2);
        jitem2.addActionListener(new java.awt.event.ActionListener(){
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt1){
                jitem2ActionPerformed(evt1);
        }
        });
        
        
        jitem3 =new JMenuItem("Calculator 2");
        menu.add(jitem3);
        
        jitem4 = new JMenuItem("Exit");
        menu.add(jitem4);
        jitem4.addActionListener(new java.awt.event.ActionListener(){
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt2){
                jitem4ActionPerformed(evt2);
        }
        });
        
        
        xpanel = new JPanel();
        xpanel.setLayout(new GridLayout(3,2));
        xpanel.setBorder(BorderFactory.createLineBorder(Color.black));
        xpanel.setBackground(Color.CYAN);
               
        
        ypanel = new JPanel();
        ypanel.setLayout(new GridLayout(3,2));
        ypanel.setBorder(BorderFactory.createEtchedBorder());
        ypanel.setBackground(Color.CYAN);
        
        xlabel = new JLabel("x=");
        xlabel.setAlignmentX(Component.RIGHT_ALIGNMENT);
        xfield = new JTextField("0", 5);
        xpanel.add(xlabel);
        xpanel.add(xfield);
        


        ylabel = new JLabel("y=");
        ylabel.setAlignmentX(Component.RIGHT_ALIGNMENT);
        yfield = new JTextField("0", 5);
        xpanel.add(ylabel);
        xpanel.add(yfield);
        

        xpanel.add(new JLabel("Result ="));
        result = new JLabel("0");
        result.setFont(new Font("Arial",Font.BOLD,13));
        result.setForeground(Color.red);
        result.setBackground(Color.yellow);
        result.setOpaque(true);
        xpanel.add(result);
        frame.add(xpanel, BorderLayout.NORTH);
        frame.add(ypanel, BorderLayout.SOUTH);
                
        
        plus = new JButton("+");
        ypanel.add(plus, BorderLayout.LINE_START);
        plus.addActionListener(new java.awt.event.ActionListener(){
            public void actionPerformed(java.awt.event.ActionEvent evt){
                plusActionPerformed(evt);
            }
        });
        
        minus = new JButton("-");
        ypanel.add(minus, BorderLayout.AFTER_LINE_ENDS);
        minus.addActionListener(new java.awt.event.ActionListener(){
            public void actionPerformed(java.awt.event.ActionEvent evt){
                minusActionPerformed(evt);
            }
        });
        
        divide = new JButton("/");
        ypanel.add(divide, BorderLayout.AFTER_LINE_ENDS);
        divide.addActionListener(new java.awt.event.ActionListener(){
            public void actionPerformed(java.awt.event.ActionEvent evt){
                divideActionPerformed(evt);
            }
        });
        
        
        
        multiply = new JButton("*");
        ypanel.add(multiply, BorderLayout.AFTER_LINE_ENDS);
        multiply.addActionListener(new java.awt.event.ActionListener(){
            public void actionPerformed(java.awt.event.ActionEvent evt){
                multiplyActionPerformed(evt);
            }
        });
        
        clear = new JButton("Clear");
        ypanel.add(clear, BorderLayout.AFTER_LINE_ENDS);
        clear.addActionListener(new java.awt.event.ActionListener(){
            public void actionPerformed(java.awt.event.ActionEvent evt){
                clearActionPerformed(evt);
            }
        });
        

        frame.pack();
        frame.setVisible(true);
        
  }
    
    private void jitemActionPerformed(java.awt.event.ActionEvent evt){
      JOptionPane.showMessageDialog(null,"Name: Shreyas Javvadhi\nLetter code: JAVV");
    }
        
    private void jitem2ActionPerformed(java.awt.event.ActionEvent evt1){
        JOptionPane.showMessageDialog(null,"This project teaches us how to use Netbeans and its different components.\n"
                + "We create two different calculators.\nOne with button operations and the other with radiobutton and checkboxes.");
    }    
    
    private void jitem4ActionPerformed(java.awt.event.ActionEvent evt2){
      System.exit(0);
    }
    
    private void multiplyActionPerformed(java.awt.event.ActionEvent evt)
      {
        int x = 0;
        int y = 0;

        String xText = xfield.getText();
        String yText = yfield.getText();

        try
          {
            x = Integer.parseInt(xText);
            y = Integer.parseInt(yText);
            result.setText(Integer.toString(x*y));
          }
        catch (NumberFormatException e)
          {
            
            result.setText("ERROR");
          }

        
      }

    private void clearActionPerformed(java.awt.event.ActionEvent evt)
      {
        
        xfield.setText("0");
        yfield.setText("0");
        result.setText("0");
        
      }
    
    private void divideActionPerformed(java.awt.event.ActionEvent evt)
      {
        int x = 0;
        int y = 0;

        String xText = xfield.getText();
        String yText = yfield.getText();

        try
          {
            x = Integer.parseInt(xText);
            y = Integer.parseInt(yText);
            if(y==0)
                result.setText("Divide by zero");
            else
              result.setText(Integer.toString(x/y));  
          }
        catch (NumberFormatException e)
          {
                       
              result.setText("ERROR");
                         
              
          }

        
      }
    
    private void minusActionPerformed(java.awt.event.ActionEvent evt)
      {
        int x = 0;
        int y = 0;

        String xText = xfield.getText();
        String yText = yfield.getText();

        try
          {
            x = Integer.parseInt(xText);
            y = Integer.parseInt(yText);
            result.setText(Integer.toString(x-y));
          }
        catch (NumberFormatException e)
          {
            result.setText("ERROR");
          }

        
      }
   
    private void plusActionPerformed(java.awt.event.ActionEvent evt)
      {
        int x = 0;
        int y = 0;

        String xText = xfield.getText();
        String yText = yfield.getText();

        try
          {
            x = Integer.parseInt(xText);
            y = Integer.parseInt(yText);
            result.setText(Integer.toString(x+y));
          }
        catch (NumberFormatException e)
          {
            result.setText("ERROR");
          }

        
      }
  }

